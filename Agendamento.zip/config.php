<?php

    $dbHost = '127.0.0.1';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'cadastro';

    $conexao = new mysqli ($dbHost,$dbUsername,$dbPassword,$dbName);

 
    ?>